@echo off
setlocal
set "GAME_ROOT=%~dp0"
set "PREVIEW_ROOT=%~dp0colobot-it-preview"
if not exist "%GAME_ROOT%colobot.exe" (
  echo Estrai questo pacchetto nella cartella che contiene colobot.exe.
  pause
  exit /b 1
)
if not exist "%GAME_ROOT%data\" (
  echo Cartella data non trovata accanto a colobot.exe.
  echo Questo avvio richiede la distribuzione ufficiale portatile 0.2.2-alpha.
  pause
  exit /b 1
)
set "PREVIEW_SAVE=%LOCALAPPDATA%\ColobotItalianPreview-0.1"
if not defined LOCALAPPDATA (
  echo Variabile LOCALAPPDATA non disponibile.
  pause
  exit /b 1
)
if not exist "%PREVIEW_SAVE%\" mkdir "%PREVIEW_SAVE%"
if not exist "%PREVIEW_SAVE%\colobot.ini" copy /y "%PREVIEW_ROOT%\config-iniziale.ini" "%PREVIEW_SAVE%\colobot.ini" >nul
pushd "%PREVIEW_SAVE%"
"%GAME_ROOT%colobot.exe" -datadir "%GAME_ROOT%data" -langdir "%PREVIEW_ROOT%\lang" -mod "%PREVIEW_ROOT%\mod" -savedir "%PREVIEW_SAVE%"
set "GAME_EXIT=%ERRORLEVEL%"
popd
if not "%GAME_EXIT%"=="0" (
  echo Il gioco e' terminato con codice %GAME_EXIT%.
  echo I file di prova si trovano in "%PREVIEW_SAVE%".
  pause
)
exit /b %GAME_EXIT%
